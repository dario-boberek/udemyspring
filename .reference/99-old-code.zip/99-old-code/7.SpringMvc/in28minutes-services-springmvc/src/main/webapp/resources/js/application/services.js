'use strict';

/* Services */

var AppServices = angular.module('AngularSpringApp.service', []);

AppServices.value('version', '0.1');
